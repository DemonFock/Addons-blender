# Prompt2Rig for Blender 5.3 — integration bridge

## Install
1. In Blender 5.3, open **Edit → Preferences → Get Extensions** and ensure **glTF 2.0 format** is installed/enabled.
2. Open **Edit → Preferences → Add-ons → Install from Disk** (or the add-on install button).
3. Select `prompt2rig_blender_53.zip`.
4. Enable **Prompt2Rig for Blender**.
5. In the 3D View press `N` and open the **Prompt2Rig** tab.

## Configure
- `Prompt2Rig folder`: select the existing repository folder containing `server.mjs` and `.env`.
- Keep the server URL at `http://127.0.0.1:5177`.
- Click **Start Prompt2Rig server**, then **Check server**.
- Click **Open Prompt2Rig app** for the original app workflow.

## Important architecture note
The original server's `/api/video` endpoint returns a `video_url`, not an animated `.glb`.
The actual browser app performs live MediaPipe pose tracking, Mixamo retargeting, playback/stream orchestration, and exports the animated GLB. The server's `/api/takes` endpoint only SAVES a GLB that the browser app has already exported; it does not create animation data itself.

Therefore this first Blender bridge intentionally does not pretend that a generated video is already a rigged animation. It:
- exposes the server's documented image/video generation endpoints;
- opens the original web app for the complete existing retarget/stream workflow;
- imports the exported animated GLB into Blender 5.3.

The local HQ worker is optional. If unavailable, the original app can still use its browser-side MediaPipe preview/retarget path. Do not enable the HQ option unless the worker is actually configured.

## Compatibility / known limits
- Target: Blender 5.3.
- The add-on uses Blender's glTF 2.0 importer operator `bpy.ops.import_scene.gltf`.
- Network calls are synchronous in this initial bridge and can temporarily block Blender while fal.ai is generating. For production use, the next development pass should move requests to a background worker and marshal results back onto Blender's main thread.
- Retargeting an arbitrary Blender rig is not implemented here. Prompt2Rig's retarget implementation is JavaScript/Three.js and needs a deliberate Python/BPy port or a browser automation bridge; it cannot be replaced by simply importing a GLB.
- The original Prompt2Rig repository is left untouched.

## API verified against upstream server.mjs
- `GET /` — server check
- `POST /api/video` — returns `video_url`
- `POST /api/image` — returns `image_url`
- `POST /api/takes` — accepts an already-exported GLB binary (not used to generate animation)
- `GET /api/hq/health` — optional local worker health
